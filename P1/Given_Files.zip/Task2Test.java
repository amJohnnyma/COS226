
public class Task2Test {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Test your program
    }
}
