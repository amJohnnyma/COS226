
public class PetersonLock {
    private volatile boolean[] flag = new boolean[2];
    private volatile int victim;

    public void lock(int i) {
        // TODO: Implement lock

    }

    public void unlock(int i) {
        // TODO: Implement unlock

    }
}
