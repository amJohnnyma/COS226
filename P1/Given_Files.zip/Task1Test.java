

public class Task1Test {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Test your program
    }
}
